@extends('employees.layout')
@section('content')
<div class="card">
  <div class="card-header">View Page</div>
  <div class="card-body">

        <div class="card-body">
        <h5 class="card-title">First Name : {{ $employees->fname }}</h5>
        <h5 class="card-title">Last Name : {{ $employees->lname }}</h5>
        <h5 class="card-title">NIC : {{ $employees->nic }}</h5>
        <p class="card-text">Address : {{ $employees->address }}</p>
        <p class="card-text">Contact : {{ $employees->contact }}</p>
  </div>

    {{-- </hr> --}}

  </div>
</div>
