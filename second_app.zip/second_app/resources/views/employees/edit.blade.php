
@extends('employees.layout')
@section('content')
<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">

      <form action="{{ url('employees/' .$employees->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$employees->id}}" id="id" />
        <label>First Name</label></br>
        <input type="text" name="fname" id="name" value="{{$employees->fname}}" class="form-control"></br>
        <label>Last Name</label></br>
        <input type="text" name="lname" id="name" value="{{$employees->lname}}" class="form-control"></br>
        <label>NIC</label></br>
        <input type="text" name="nic" id="name" value="{{$employees->nic}}" class="form-control"></br>
        <label>Address</label></br>
        <input type="text" name="address" id="address" value="{{$employees->address}}" class="form-control"></br>
        <label>Contact</label></br>
        <input type="text" name="contact" id="mobile" value="{{$employees->contact}}" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>

  </div>
</div>
@stop
