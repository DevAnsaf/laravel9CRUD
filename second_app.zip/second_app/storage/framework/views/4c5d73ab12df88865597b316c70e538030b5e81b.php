<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">View Page</div>
  <div class="card-body">

        <div class="card-body">
        <h5 class="card-title">First Name : <?php echo e($employees->fname); ?></h5>
        <h5 class="card-title">Last Name : <?php echo e($employees->lname); ?></h5>
        <h5 class="card-title">NIC : <?php echo e($employees->nic); ?></h5>
        <p class="card-text">Address : <?php echo e($employees->address); ?></p>
        <p class="card-text">Contact : <?php echo e($employees->contact); ?></p>
  </div>

    

  </div>
</div>

<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\framework\laravel\second_app\resources\views/employees/show.blade.php ENDPATH**/ ?>